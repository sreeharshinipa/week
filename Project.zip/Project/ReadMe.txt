1. Download and Install the python application. 
2. Manage the virtual environment 
3. Manage PIP function  
4. Install Django application using PIP. 
5. New project is created in the Django application 
6. Local server is opened and test the URL
7. verify the message given. 

